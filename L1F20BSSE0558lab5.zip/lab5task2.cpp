#include<iostream>
using namespace std;

template<typename t>
class queue{
private:
	t* arr;
	int rear;
	int front;
	int max;
public:
	queue(int m)
	{
		max = m;
		arr = new t[max];
		rear = -1;
		front = -1;
	}
	bool isfull()
	{
		if (rear == max - 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool isempty()
	{
		if (rear == -1 && front == -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	void enqueue(t val)
	{
		if (isfull())
		{
			cout << "queue full\n";
		}
		else
		{
			rear++;
			arr[rear] = val;
		}
	}
	t dequeue()
	{
		if (isempty())
		{
			cout << "queueu empty\n";
		}
		else
		{
			front++;
			t temp = arr[front];
			arr[front] = 0;
			return temp;
		}
	}
	void sort()
	{
		for (int i = 0; i < max; i++)
		{
			for (int j = 0; j < max; j++)
			{
				t temp;
				if (arr[i] < arr[j])
				{
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
	}
	void display()
	{
		for (int i = 0; i < max; i++)
		{
			cout << arr[i] << "   ";
		}
		cout << endl;
	}
};


int main()
{
	queue<int> q(5);
	q.enqueue(7);
	q.enqueue(2);
	q.enqueue(5);
	q.enqueue(10);
	q.enqueue(3);
	cout << "unsorted :  ";
	q.display();
	q.sort();
	cout << "sorted :  ";
	q.display();

	system("pause");
}