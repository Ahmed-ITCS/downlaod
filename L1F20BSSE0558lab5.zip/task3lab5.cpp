#include<iostream>
using namespace std;

template<typename t>
class stack{
private:
	t* arr;
	int max;
	int current;
public:
	stack(int max)
	{
		this->max = max;
		arr = new t[max];
		current = -1;
		for (int i = 0; i <max; i++)
		{
			arr[i] = 0;
		}
	}
	bool isfull()
	{
		if (current == max - 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool isempty()
	{
		if (current == -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	void push(t val)
	{
		if (isfull())
		{
			cout << "full hain bero\n";
		}
		else
		{
			current++;
			arr[current] = val;

		}
	}
	t pop()
	{
		if (isempty())
		{
			cout << "khaali hain bro - apki rooh ki tarha\n";
			return 0;
		}
		else
		{
			t temp = arr[current];
			arr[current] = 0;
			current--;
			return temp;
		}

	}
	void display()
	{
		for (int i = max - 1; i >= 0; i--)
		{
			cout << arr[i] << "\n";
		}
	}

};

template<typename tt>
class circularqueue{
private:
	tt* arr;
	int rear;
	int front;
	int max;
public:
	circularqueue(int m)
	{
		max = m;
		arr = new tt[max];
		rear = -1;
		front = -1;
	}
	bool isfull()
	{
		if ((rear + 1) % max == front)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool isempty()
	{
		if (rear == -1 && front == -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	void enqueue(tt val)
	{
		if (isfull())
		{
			cout << "queue full\n";
		}
		else if (isempty())
		{
			front++;
			rear++;
			arr[rear] = val;
		}
		else
		{
			rear = (rear + 1) % max;
			arr[rear] = val;
		}
	}
	tt dequeue()
	{
		if (isempty())
		{
			cout << "queueu empty\n";
		}
		else if (front == rear)
		{
			front = -1;
			rear = -1;

		}
		else
		{
			tt temp = arr[front];
			arr[front] = 0;
			front = (front + 1) % max;
			return temp;
		}
	}
	void display()
	{
		for (int i = 0; i < max; i++)
		{
			cout << arr[i] << "   ";
		}
		cout << endl;
	}
};


int main()
{
	int size = 5;
	stack<int> s(size);
	circularqueue<int> q1(size);
	circularqueue<int> q2(size);
	int n = 11;
	while (n != 16)
	{
		q1.enqueue((n % 10));
		q2.enqueue((n / 10));
		n++;
	}
	int quot = 0;
	q1.display();
	q2.display();
	while (size != 0)
	{
		int deq1 = q1.dequeue();
		int deq2 = q2.dequeue();
		int result = deq1 + deq2 + quot;
		s.push(result % 10);
		quot = result / 10;
		size--;
	}
	stack<int> s2(5);
	while (!s.isempty())
	{
		s2.push(s.pop());
	}
	
	s2.display();
	system("pause");
}