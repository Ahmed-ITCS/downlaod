#include<iostream>
#include<string>
using namespace std;

template<typename t>
class stack{
private:
	t* arr;
	int top;
	int max;
public:
	stack(int m)
	{
		max = m;
		top = -1;
		arr = new t[m];
		for (int i = 0; i < m; i++)
		{
			arr[i] = 0;
		}
	}
	bool isfull()
	{
		if (top == max - 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool isempty()
	{
		if (top == -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	void push(t val)
	{
		if (isfull())
		{
			cout << "full hain\n";
		}
		else
		{
			top++;
			arr[top] = val;
		}
	}
	t pop()
	{
		if (isempty())
		{
			cout << "empty bro\n";
		}
		else
		{
			t temp = arr[top];
			arr[top] = 0;
			top--;
			return temp;
		}
	}
	void display()
	{
		for (int i = 0; i <=top; i++)
		{
			cout << arr[i] << "  ";
		}
		cout << endl;
	}
};

int main()
{
	string infix = "";
	char eq[40];
	cout << "enter your infinix : ";
	cin >> eq;
	int op = 0;
	for (int i = 0; eq[i] != '\0'; i++)
	{
		if (eq[i] == '+' || eq[i] == '-' || eq[i] == '*' || eq[i] == '/' || eq[i] == '(')
		{
			op++;
		}
	}
	stack<char> s(op);
	for (int i = 0; eq[i] != '\0'; i++)
	{
		if (eq[i] == '+' || eq[i] == '-' || eq[i] == '*' || eq[i] == '/' || eq[i] == '(')
		{
			s.push(eq[i]);
		}
		else if (eq[i] == ')')
		{
			//s.push(eq[i]);
		here:
			char temp = s.pop();
			if (temp != '(')
			{
				infix += temp;
				goto here;
			}
			else
			{
				continue;
			}
		}
		else
		{
			infix += eq[i];
		}
	}
	while (!s.isempty())
	{
		char temp = s.pop();
		infix += temp;
	}

	cout << "your post fix is  :  " << infix<<"\nevaluating\n";
	stack<int> ss(10);
	int operand1;
	int operand2;
	int resultt;
	for (int i = 0; infix[i] != '\0'; i++)
	{
		if (infix[i] >= '0'&&infix[i] <= '9')
		{
			int n = infix[i];
			n = n - 48;
			ss.push(n);
			
		}
		else
		{
			operand2 = ss.pop();
			operand1 = ss.pop();
			if (infix[i] == '+')
			{
				ss.push(operand1 + operand2);
			}
			else if (char(infix[i]) == '-')
			{
				ss.push(operand1 + operand2);
			}
			else if (char(infix[i]) == '*')
			{
				ss.push(operand1 + operand2);
			}
			else if (char(infix[i]) == '/')
			{
				ss.push(operand1 + operand2);
			}

		}
	}
	cout << "your evaluted postfix is ";
	ss.display();
	system("pause");


}