#include<iostream>
using namespace std;

template<typename t>
class queue{
private:
	t* arr;
	int rear;
	int front;
	int max;
public:
	queue(int m)
	{
		max = m;
		rear = -1;
		front = -1;
		arr = new t[m];
		for (int i = 0; i < max; i++)
		{
			arr[i] = 0;
		}

	}
	queue(queue& obj)
	{
		arr = obj.arr;
		rear = obj.rear;
		front = obj.front;
	}
	bool isfull()
	{
		if (rear == max - 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool isempty()
	{
		if (rear == -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	void enque(t val)
	{
		if (isfull())
		{
			cout << "que full\n";
		}
		else
		{
			rear++;
			arr[rear] = val;
		}
	}
	t dequeu()
	{
		if (isempty())
		{
			cout << "empty\n";
		}
		else
		{
			front++;
			t temp = arr[front];
			arr[front] = 0;
			return temp;
		}
	}
	void display()
	{
		for (int i = 0; i < max; i++)
		{
			cout << arr[i] << "  ";
		}
		cout << endl;
	}
	~queue()
	{
		delete[] arr;
		arr = nullptr;
	}
};


int main()
{
	cout << "enter size of queue  :  ";
	int size;
	cin >> size;
	queue<int> q(size);
	while (1)
	{
		cout << "Press 1 to add item to the queue\nPress 2 to remove item from the queue\nPress 3 to check if the queue is full\nPress 4 to check if the queue is empty\nPress 5 to display the queue\nPress 6 to exit   :";
		cin >> size;
		if (size == 1)
		{
			cout << "enter number to enter in que : ";
			int n;
			cin >> n;
			q.enque(n);

		}
		else if (size == 2)
		{
			cout << q.dequeu();
		}
		else if (size == 3)
		{
			cout << "is full ? " << q.isfull();
		}
		else if (size == 4)
		{
			cout << "is empty ? " << q.isempty();
		}
		else if (size == 5)
		{
			q.display();
		}
		else if (size == 6)
		{
			break;
		}
		else
		{
			cout << "invalid enter again\n";
		}
	}



	system("pause");


}