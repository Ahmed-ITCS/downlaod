#include<iostream>
using namespace std;

template<typename t>
class stack{
private:
	t* arr;
	int max;
	int current;
public:
	stack(int max)
	{
		this->max = max;
		arr = new t[max];
		current = -1;
	}
	bool isfull()
	{
		if (current == max - 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool isempty()
	{
		if (current == -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	void push(t val)
	{
		if (isfull())
		{
			cout << "full hain bero\n";
		}
		else
		{
			current++;
			arr[current] = val;

		}

	}
	t pop()
	{
		if (isempty())
		{
			cout << "khaali hain bro - apki rooh ki tarha\n";
		}
		else
		{
			t temp = arr[current];
			arr[current] = 0;
			current--;
			return temp;
		}

	}
	void display()
	{
		for (int i = max - 1; i >= 0; i--)
		{
			cout << arr[i] << "\n";
		}
	}

};

int main()
{
	char sen[50];
	cout << "enter sentence : ";
	cin >> sen;
	int c = 0;
	for (int i = 0; sen[i] != '\0'; i++)
	{
		c++;
	}
	stack<char> p(c);
	for (int i = 0; i<c; i++)
	{
		p.push(sen[i]);
	}
	bool issame;
	for (int i = 0, j = c - 1; i < c; i++, j--)
	{

		if (sen[i] == sen[j])
		{
			issame = true;
		}
		else
		{
			issame = false;
			break;
		}

	}
	if (issame)
	{
		cout << "palindrome\n";
	}
	else
	{
		cout << "not palindrome\n";
	}
	cout << "\nstack is \n";
	p.display();
	system("pause");
}
