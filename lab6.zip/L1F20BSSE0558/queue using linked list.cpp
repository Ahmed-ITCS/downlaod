#include<iostream>
using namespace std;

template <typename t>
class node{
private:
	t data;
	node* next;
public:
	node()
	{
		next nullptr;
	}
	node(t data)
	{
		this->data = data;
		next = nullptr;
	}
	void setdata(t d)
	{
		data = d;
	}
	void setnext(node* n)
	{
		next = n;
	}
	node* getnext()
	{
		return next;
	}
	t getdata()
	{
		return data;
	}
};

template<typename tt>
class queue{
private:
	node<tt>* front;
	node<tt>* back;
public:
	queue()
	{
		front = nullptr;
		back = nullptr;
	}
	void enqueue(tt data)
	{
		node<tt>* neww = new node<tt>(data);
		if (back == nullptr)
		{
			neww->setnext(back);
			front = neww;
			back = neww;
			return;
		}
		
		neww->setnext(back);
		back = neww;
	}
	tt dequeue()
	{
		tt temp = front->getdata();
		front = front->getnext();
		return temp;
	}
	void display()
	{
		node<tt>* t = back;
		while (t != nullptr)
		{
			cout << t->getdata()<<"  ";
			t = t->getnext();
		}
		cout << endl;
	}
	tt get_front()
	{
		return front->getdata();
	}
	tt get_back()
	{
		return back->getdata();
	}

};
int main()
{
	queue<int> q;
	q.enqueue(1);
	q.enqueue(2);
	q.enqueue(3);
	q.enqueue(4);
	cout << q.get_back()<<endl;
	cout << q.get_front() << endl;
	
	q.display();
	

	system("pause");
}