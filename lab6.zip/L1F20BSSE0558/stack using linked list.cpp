#include<iostream>
using namespace std;

template <typename t>
class node{
private:
	t data;
	node* next;
public:
	node()
	{
		next nullptr;
	}
	node(t data)
	{
		this->data = data;
		next = nullptr;
	}
	void setdata(t d)
	{
		data = d;
	}
	void setnext(node* n)
	{
		next = n;
	}
	node* getnext()
	{
		return next;
	}
	t getdata()
	{
		return data;
	}
};
template<typename tt>
class stack{
private:
	node<tt>* top;
public:
	stack()
	{
		top = nullptr;
	}
	void push(tt data)
	{
		node<tt>* neww = new node<tt>(data);
		neww->setnext(top);
		top = neww;
	}
	tt pop()
	{
		tt temp = top->getdata();
		node<tt>* del = top;
		top = top->getnext();
		delete[] del;
		del = nullptr;
		return temp;
	}
	void display()
	{
		node<tt>* t = top;
		while (t !=nullptr)
		{
			cout << t->getdata() << "\n";
			t = t->getnext();
		}
		cout << endl;
	}
	tt peek()
	{
		return top->getdata();
	}

};


int main()
{
	stack<int> s;
	s.push(1);
	s.push(2);
	s.push(3);
	s.push(4);
	s.push(5);
	s.push(6);
	s.push(7);
	s.push(8);
	s.display();
	system("pause");
}