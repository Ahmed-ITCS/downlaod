#include<iostream>
using namespace std;

template <typename t>
class node{
private:
	t data;
	node* next;
public:
	node()
	{
		next = nullptr;
	}
	node(t data)
	{
		this->data = data;
		next = nullptr;
	}
	void setdata(t d)
	{
		data = d;
	}
	void setnext(node* n)
	{
		next = n;
	}
	node* getnext()
	{
		return next;
	}
	t getdata()
	{
		return data;
	}
};


template<typename tt>
class sll{
private:
	node<tt>* head;
	node<tt>* tail;
	int count;
public:
	sll()
	{
		count = 0;
		head = nullptr;
		tail = nullptr;
	}
	void insetAtFront(tt d)
	{
		count++;
		node<tt>* neww = new node<tt>(d);
		if (head == nullptr)
		{
			head = neww;
			head->setnext(tail);
		}
		else
		{
			neww->setnext(head);
			head = neww;
		}


	}
	void insertAtEnd(tt d)
	{
		count++;
		node<tt>* neww = new node<tt>(d);
		if (tail == nullptr)
		{
			node<tt>* t = head;
			while (t->getnext() != nullptr)
			{
				t = t->getnext();
			}
			tail = neww;
			t->setnext(tail);
		}
		else
		{
			node<tt>* t = tail;
			while (t->getnext() != nullptr)
			{
				t = t->getnext();
			}
			t->setnext(neww);
			tail = neww;

		}

	}
	void show()
	{
		node<tt>* t = head;
		while (t != nullptr)
		{
			cout << t->getdata() << "  ";
			t = t->getnext();
		}
		cout << endl;
	}
	tt front()
	{
		return head->getdata();
	}
	tt back()
	{
		return tail->getdata();
	}
	void removefromfront()
	{
		count--;
		node<tt>* t = head;
		head = head->getnext();
		delete[] t;
		t = nullptr;
	}
	void removefromback()
	{
		count--;
		node<tt>* temp = head;
		node<tt>* temp2 = head->getnext();
		while (temp2->getnext() != nullptr)
		{
			temp2 = temp2->getnext();
			temp = temp->getnext();
		}
		tail = temp;
		tail->setnext(nullptr);
		delete[] temp2;
		temp2 = nullptr;


	}
	int size()
	{
		return count;
	}
	bool empty()
	{
		if (head == nullptr &&  tail == nullptr)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	int search(int k)
	{
		int c = 0;
		node<tt>* temp = head;
		while (temp != nullptr)
		{
			if (temp->getdata() == k)
			{
				c++;
			}
			temp = temp->getnext();

		}
		return c;
	}
	
};
int main()
{
	sll<int> s;
	s.insetAtFront(1);
	s.insetAtFront(2);
	s.insetAtFront(3);
	s.insertAtEnd(4);
	s.insertAtEnd(5);
	s.insertAtEnd(1);
	s.show();
	cout << s.front() << endl;
	cout << s.back() << endl;
	s.removefromfront();
	s.removefromback();
	s.show();
	cout << s.empty() << endl;
	cout << s.size() << endl;
	s.insertAtEnd(8);
	s.insetAtFront(8);
	cout << s.search(8) << endl;
	s.show();
	system("pause");
}