#include<iostream>
#include<string>
using namespace std;

template<typename t>
class circularqueue{
private:
	t* arr;
	int rear;
	int front;
	int max;
public:
	circularqueue(int m)
	{
		arr = new t[m];
		rear = -1;
		front = -1;
		max = m;
	}
	bool isfull()
	{
		if ((rear+1)%max==front)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool isempty()
	{
		if (rear == -1 && front ==- 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	void enqueue(t val)
	{
		if (isfull())
		{
			cout << "full \n";
		}
		else if (isempty())
		{
			front++;
			rear++;
			arr[rear] = val;
		}
		else
		{
			rear = (rear + 1) % max;
			arr[rear] = val;
		}
	}
	t dequeue()
	{
		if (isempty())
		{
			cout << "empty\n";
		}
		else if (front == rear)
		{
			front = -1;
			rear = -1;
		}
		else
		{
			t temp = arr[front];
			arr[front] = "  ";
			front = (front + 1) % max;
			return temp;
		}
	}
	void display()
	{
		for (int i = 0; i < max; i++)
		{
			cout << arr[i] << "  ";
		}
		cout << endl;
	}
};

int main()
{
	circularqueue<string> q(5);
	while (1)
	{
		char u;
		cout << "enter 1 to add song to queue \nenter 2 see the queue\nenter 3 to play a song\nenter  ";
		cin >> u;
		if (u == '1')
		{
			string task;
			cout << "enter song : ";
			cin.ignore();
			getline(cin,task);			
			q.enqueue(task);
		}
		else if (u == '2')
		{
			q.display();
		}
		else if (u == '3')
		{
			q.dequeue();
		}
		else
		{
			break;
		}
		system("pause");
		system("cls");

	}

	system("pause");


}
