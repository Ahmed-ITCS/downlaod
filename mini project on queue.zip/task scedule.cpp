#include<iostream>
#include<Windows.h>
using namespace std;
//first come first serve
template<typename t>
class circularqueue{
	t* arr;
	int rear;
	int front;
	int max;
	int CPU;
	int* taskcpu;
	int i;
public:
	circularqueue(int m)
	{
		CPU = 50;
		max = m;
		rear = -1;
		front = -1;
		taskcpu= new int[m];
		arr = new t[m];
		i = 0;
		for (int j = 0; j <max; j++)
		{
			taskcpu[j] = 0;

		}
	}
	bool isfull()
	{
		if ((rear + 1) % max == front)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool isempty()
	{
		if (rear ==-1&&front ==-1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	void enqueue(t val, int& cpuu)
	{
		if (isfull())
		{
			cout << "full\n";
		}
		else if (isempty())
		{
			front++;
			rear++;
			if (cpuu <= CPU)
			{
				CPU = CPU - cpuu;
				taskcpu[i] = cpuu;
				i++;
				arr[rear] = val;
			}
			else
			{
				cout << "CPU not avaiabele\n";
				
			}
			

		}
		else
		{
			
			if (cpuu <= CPU)
			{
				CPU = CPU - cpuu;
				taskcpu[i] = cpuu;
				rear = (rear + 1) % max;
				arr[rear] = val;
				i++;
			}
			else
			{
				cout << "CPU not avaiabele\n";
			}
		}
	}
	t deque()
	{
		if (isempty())
		{
			cout << "is empty bro \n";
		}
		else if (front == rear)
		{
			front = -1;
			rear = -1;
			for (int j = 0; j < max; j++)
			{
				taskcpu[j] = 0;
				CPU = 50;
			}
			i = 0;
		}
		else
		{
			t temp = arr[front];
			arr[front] = '0';
			front = (front + 1) % max;
			int c = taskcpu[i];
			CPU = c + CPU;
			taskcpu[i] = 0;
			i--;
			return temp;
		}
	}
	void display()
	{
		for (int i = 0; i < max; i++)
		{
			cout << arr[i] << "   ";
		}
		cout << "\ncpu task are ";
		for (int i = 0; i < max; i++)
		{
			cout << taskcpu[i] << "   ";
		}
		cout << "\n";
	}
	void intrupt(char task)
	{
		int index;
		for (int i = 0; i < max; i++)
		{
			if (arr[i] == task)
			{
				index = i;
				break;
			}
		}
		
		char temp = arr[0];
		arr[0] = arr[index];
		arr[index] = temp;
			
		int tempp = taskcpu[0];
		taskcpu[0] = taskcpu[index];
		taskcpu[index] = tempp;

	}

};



int main()
{
	char task;
	int taskcpu;
	circularqueue<char> q(5);
	while (1)
	{
		char u;
		cout << "enter 1 to enter CPU task\nenter 2 for display\nenter 3 to deque\nenter 4 to accomodate inturpts";
		cin >> u;
		if (u == '1')
		{
			cout << "enter task : ";
			cin >> task;
			cout << "enter it's cpu usage : ";
			cin >> taskcpu;
			q.enqueue(task, taskcpu);
		}
		else if (u == '2')
		{
			q.display();
		}
		else if (u=='3')
		{
			q.deque();
		}
		else if (u == '4')
		{
			q.display();
			cout << "enter the task you want to intrupt\n";
			cin >> task;
			q.intrupt(task);

		}
		else
		{
			break;
		}
		system("pause");
		system("cls");

	}

	system("pause");


}